#!/bin/bash
# run_examples.sh
# Batch file to run all DeSiO-Examples. on Luis Cluster
clear
my_desio="/bigwork/nhgehent/DeSiO"
mypath="$(pwd)"
#rm "output_l.log" 
#echo "Start running DeSiO - examples in " $mypath >> $mypath/output_l.log
# Loop over directories in DeSiO_Example
for f1 in $mypath/*; do
	# if file is directory then
    	if [ -d "$f1" ]; then
			f2=$f1
			f3=$f2
			cd "$f3"
			jobname="${f2##*/}"
			cp $my_desio/my_slurm_set.txt $mypath/run_cluster_l.sh
			echo "#SBATCH --job-name=$jobname" >> $mypath/run_cluster_l.sh
			cat $my_desio/DeSiO_path_set.txt >> $mypath/run_cluster_l.sh 
			cp $mypath/run_cluster_l.sh $f3
			# send job to cluster, defined in run_cluster.sh
			sbatch run_cluster_l.sh
	fi
done
rm $mypath/run_cluster_l.sh
